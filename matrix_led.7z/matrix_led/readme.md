## Exersice 1


* Connect an LED to pin P9.5 of the MSP430
* Connect one button to pin P2.1 of the MSP430


## Board interfaces(?)

* LED_1(red)     P1.0
* LED_2(green)   P9.7
* BUTTON_1       P1.1
* BUTTON_2       P1.2


