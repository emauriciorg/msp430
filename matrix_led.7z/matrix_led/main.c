#include <msp430.h>

void delay(void) {
volatile unsigned loops = 5000; // Start the delay counter at 25,000
while (--loops > 0); // Count down until the delay counter reaches 0
}


int main(void)
{
	unsigned char rowcnt; // row counter
	unsigned char matrix[8]= {0x01 , 0x03 ,0x07 , 0x0f , 0x1f,  0x3f, 0x7f, 0xff};

	WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

	P2DIR |= (BIT6 | BIT7);   // Make Port 2.6 and 2.7 outputs
	P2OUT &= ~(BIT6 | BIT7);  // Set ports to 0

	/*setting  the led matrix column pins as output*/	
	P9DIR |= (BIT0| BIT1 |BIT2|BIT3|BIT4|BIT5|BIT6);  // P6DIR=0x7f;
	P9OUT &=~(BIT0| BIT1 |BIT2|BIT3|BIT4|BIT5|BIT6);  // P6DIR=0x7f;

	P8DIR|= (BIT7);
	P8OUT&=~(BIT7);
	
	/*Setting port alternate function to be I/O*/
	P9SEL0 &=~(BIT0| BIT1 |BIT2|BIT3|BIT4|BIT5|BIT6);
	P9SEL1 &=~(BIT0| BIT1 |BIT2|BIT3|BIT4|BIT5|BIT6);
	
	P8SEL0 &=~(BIT7);
	P8SEL1 &=~(BIT7);

	PM5CTL0 &= ~LOCKLPM5; // Unlock ports from power manager

	rowcnt = 0;
	
	while(1)// continuous loop
	{
		delay();
		if(P2OUT & BIT6) // If row clock 1 -> place breakpoint here
			P2OUT &= ~BIT6;  //   Set row clock 0
		else {


			P9OUT &=~0x7f; /*clears the row port*/
			P9OUT |=matrix[ rowcnt] & 0X7F;
			P8OUT &=~(BIT7);
			P8OUT |=(BIT7 & (matrix[ rowcnt]&0x80));

			if(rowcnt == 7) {// if on row 7
				P2OUT |= (BIT6 | BIT7);  //   Set row clock and row init 1
				rowcnt = 0;  //   set row counter back to 0

			} else { // for all other rows

				P2OUT &= ~BIT7;  //   set row init to 0
				P2OUT |= BIT6;   //   only set row clock 1
				rowcnt++;//   increment row counter
			}

		}

	}

	return 0;
}
